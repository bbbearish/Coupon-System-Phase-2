package com.restServices.rest;

import javax.ws.rs.NotFoundException;
import javax.ws.rs.core.Response;
import javax.ws.rs.ext.ExceptionMapper;
import javax.ws.rs.ext.Provider;

import com.coupon.exceptions.CouponProjectException.AccessForbiddenException;
import com.coupon.exceptions.CouponProjectException.CompanyException;
import com.coupon.exceptions.CouponProjectException.CustomerException;
import com.coupon.exceptions.CouponProjectException.LoginException;

//done...................
/**
 * CouponProjectExceptionMapper - an ExceptionMapper.<br><br>
 * 
 * The ExceptionMapper is used to map (translate) Exception(s) to a proper servlet Response.
 * That response can then be handled by the client (the web service client).
 * @author Elad
 *
 */
@Provider
public class CouponProjectExceptionMapper implements ExceptionMapper<Exception> {
	
	public CouponProjectExceptionMapper() {
		super();
        System.out.println("CouponProjectExceptionMapper created");
    }

	@Override
	public Response toResponse(Exception e) {
		//return Response.status(Response.Status.INTERNAL_SERVER_ERROR).entity(e.getMessage()).type("text/plain").build();
		
		// default
		Response.Status status = Response.Status.INTERNAL_SERVER_ERROR;

		// CouponProject exception
		if (e instanceof AccessForbiddenException) {
			status = Response.Status.FORBIDDEN;
	    	e.printStackTrace();

		} 
		if (e instanceof LoginException) {
			status = Response.Status.UNAUTHORIZED;
	    	e.printStackTrace();

		} 
		else if (e instanceof CompanyException) {
			status = Response.Status.BAD_REQUEST;
	    	e.printStackTrace();

		} 
		else if (e instanceof CustomerException) {
			status = Response.Status.BAD_REQUEST;
	    	e.printStackTrace();

		} 
		// jersey exception
		else if (e instanceof NotFoundException) {
			status = Response.Status.NOT_FOUND;
	    	e.printStackTrace();

		}
		// json exceptions
		else { // check by class name 
			String name = e.getClass().getSimpleName();
		    if (name.equals("JsonMappingException")) {
		    	status = Response.Status.BAD_REQUEST;
		    	e.printStackTrace();
		    	

		    }
		    else if (name.equals("UnrecognizedPropertyException")) {
		    	status = Response.Status.BAD_REQUEST;
		    	e.printStackTrace();
		    }
		}
		
		return Response.status(status).entity(e.toString()).type("text/plain").build();
	}
}
