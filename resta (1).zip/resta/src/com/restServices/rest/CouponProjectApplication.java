package com.restServices.rest;

import javax.ws.rs.ApplicationPath;
import javax.ws.rs.core.Application;
import java.util.Set;
/**
 * 
 * Registers the classes that should be used by jersey.
 * This is needed when using deployment agnostic application model.
 * @author Elad
 *
 */

@ApplicationPath("rest")
public class CouponProjectApplication extends Application {


	@Override
	public Set<Class<?>> getClasses(){
		Set<Class<?>>resources = new java.util.HashSet<>();
		addRestResourceClasses(resources);
		return resources;
	}

	private void addRestResourceClasses(Set<Class<?>> resources) {

		resources.add(com.rest.services.LoginLogOutService.class);

		resources.add(com.rest.services.AdminService.class);
		resources.add(com.rest.services.CompanyService.class);
		resources.add(com.rest.services.CustomerService.class);


		// need to add ExceptionMapper class as well
		resources.add(com.restServices.rest.CouponProjectExceptionMapper.class);        

	}

}
