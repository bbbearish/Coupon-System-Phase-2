package com.rest.services;

import java.util.Collection;

import javax.servlet.http.HttpServletRequest;
import javax.ws.rs.Consumes;
import javax.ws.rs.DELETE;
import javax.ws.rs.GET;
import javax.ws.rs.POST;
import javax.ws.rs.PUT;
import javax.ws.rs.Path;
import javax.ws.rs.PathParam;
import javax.ws.rs.Produces;
import javax.ws.rs.core.Context;
import javax.ws.rs.core.MediaType;

import org.apache.log4j.Logger;

import com.coupon.basic.Company;
import com.coupon.basic.Customer;
import com.coupon.couponSystem.CouponSystem;
import com.coupon.exceptions.CouponProjectException;
import com.coupon.exceptions.CouponProjectException.LoginException;
import com.coupon.facade.AdminFacade;
import com.coupon.util.Utils;
import com.rest.auth.AuthUtils;

//done..........
/**
 * Sets the path to base URL + /admin
 * @author Elad
 *
 */
@Path("/admin")
@Produces(MediaType.APPLICATION_JSON)
public class AdminService {

	static Logger logger = Logger.getLogger(AdminService.class);

	@Context
	HttpServletRequest request;

	
	private AdminFacade getAdminFacade() throws LoginException {
		return AuthUtils.getCredentials(AdminFacade.class, request);
	}
	
	// test
	@Path("/exception")
	@POST
	@Produces(MediaType.APPLICATION_JSON)

	public void testExceptionMapper() throws Exception {
		logger.debug("exception <<<<<<<<<<<<<<<<<<<<<<");

		throw new CouponProjectException("123 Testing the ExceptionMapper");
	}
 
	// example :
	// http://localhost:9090/resta/rest/admin/company/120
	//
	@Path("/company/{id : \\d+}") // id pattern (digits only)
	@GET
	@Produces(MediaType.APPLICATION_JSON)

 	public Company getCompany( @PathParam("id") long companyId ) throws Exception {
		logger.debug("getCompany " + companyId);

		AdminFacade adminFacade = getAdminFacade();
    	return adminFacade.getCompanyByID(companyId);
	}
	
	// example :
	// http://localhost:9090/resta/admin/company/babi
	//	
	@Path("/company/{name: [a-zA-Z][a-zA-Z_0-9%]+}") // name pattern
	@GET
	@Produces(MediaType.APPLICATION_JSON)

 	public Company getCompany( @PathParam("name") String companyName ) throws Exception {
		logger.debug("getCompany " + companyName);

		AdminFacade adminFacade = getAdminFacade();
    	return adminFacade.getCompanyByName(companyName);
	}
	
	// example :
	// http://localhost:9090/resta/admin/companyies
	//	
	@Path("/companies") 
	@GET
	@Produces(MediaType.APPLICATION_JSON)

 	public Collection<Company> getAllCompanies() throws Exception{
		logger.debug("getAllCompanies" );

		AdminFacade adminFacade = getAdminFacade();
    	return adminFacade.getAllCompanys();
	}
	
	// example :
	// http://localhost:9090/resta/admin/company
	@POST
	@Path("/company")
	@Consumes(MediaType.APPLICATION_JSON)
	@Produces(MediaType.APPLICATION_JSON)

		public void createCompany(Company company) throws Exception {
		logger.debug("createCompany " + company);

		AdminFacade adminFacade = getAdminFacade();
		
		try {
			adminFacade.createCompany(company);
		} catch (Exception e) {
			logger.error("createCompany failed : " + e.toString());
			throw e;
		}

	}	
	
	
	// example :
	// http://localhost:9090/resta/admin/company
	@PUT
	@Path("/company")
	@Consumes(MediaType.APPLICATION_JSON)
	@Produces(MediaType.APPLICATION_JSON)

 	public void updateCompany(Company company) throws Exception {
		logger.debug("updateCompany " + company);

		AdminFacade adminFacade = getAdminFacade();
		
		try {
			adminFacade.updateCompany(company);
		} catch (Exception e) {
			logger.error("updateCompany failed : " + e.toString());
			throw e;
		}

	}
	
	// example :
	// http://localhost:9090/resta/admin/company/1
	//	
	@Path("/company/{id : \\d+}") // id pattern (digits only)
	@DELETE
	@Produces(MediaType.APPLICATION_JSON)

	public void removeCompany( @PathParam("id") long companyId ) throws Exception {
		logger.debug("removeCompany " + companyId);
		
		AdminFacade adminFacade = getAdminFacade();
		adminFacade.RemoveCompanyByID(companyId);
	}
	
	@DELETE
	@Path("/company")
	@Consumes(MediaType.APPLICATION_JSON)
	@Produces(MediaType.APPLICATION_JSON)

 	public void removeCompany(Company company) throws Exception {
		logger.debug("removeCompany " + company);

		AdminFacade adminFacade = getAdminFacade();
		try {
			adminFacade.removeCompany(company);
		} catch (Exception e) {
			logger.error("removeCompany failed : " + e.toString());
			throw e;
		}

	}
	
	
	// Handling customers
	
	// example :
	// http://localhost:9090/resta/admin/customer/5
	@Path("/customer/{id : \\d+}") // id pattern (digits only)
	@GET
	@Produces(MediaType.APPLICATION_JSON)

 	public Customer getCustomer( @PathParam("id") long customerId ) throws Exception {
		logger.debug("getCompany " + customerId);

		AdminFacade adminFacade = getAdminFacade();
    	return adminFacade.getCustomerById(customerId);
	}
	
	// example :
	// http://localhost:9090/resta/admin/customer/"miss piggie"
	//
	@Path("/customer/{name: [a-zA-Z][a-zA-Z_0-9%]+}") // name pattern
	@GET
	@Produces(MediaType.APPLICATION_JSON)

 	public Customer getCustomer( @PathParam("name") String customerName ) throws Exception {
		logger.debug("getCustomer " + customerName);

		AdminFacade adminFacade = getAdminFacade();
    	return adminFacade.getCustomerByName(customerName);
	}
	
	// example :
	// http://localhost:9090/resta/admin/customers
	//
	@Path("/customers") // name pattern
	@GET
	@Produces(MediaType.APPLICATION_JSON)

 	public Collection<Customer> getAllCustomers() throws Exception{
		logger.debug("getAllCustomers" );

		AdminFacade adminFacade = getAdminFacade();
    	return adminFacade.getAllCustomers();
	}
	
	// example :
	// http://localhost:9090/resta/admin/customer
	 
	@POST
	@Path("/customer")
	@Consumes(MediaType.APPLICATION_JSON)
	@Produces(MediaType.APPLICATION_JSON)

	public void createCustomer(Customer customer) throws Exception {
		logger.debug("createCustomer " + customer);

		AdminFacade adminFacade = getAdminFacade();
		
		try {
			adminFacade.createCustomer(customer);
		} catch (Exception e) {
			logger.error("createCustomer failed : " + e.toString());
			throw e;
		}

	}	
	
	// example :
	// http://localhost:9090/resta/admin/customer 
	//		
	@PUT
	@Path("/customer")
	@Consumes(MediaType.APPLICATION_JSON)
	@Produces(MediaType.APPLICATION_JSON)
	public void updateCustomer(Customer customer) throws Exception {
		logger.debug("updateCustomer " + customer);

		AdminFacade adminFacade = getAdminFacade();
		
		try {
			adminFacade.updateCustomer(customer);
		} catch (Exception e) {
			logger.error("updateCustomer failed : " + e.toString());
			throw e;
		}

	}
	
	// example :
	// http://localhost:9090/resta/admin/customer/5
	//			
	@Path("/customer/{id : \\d+}") // id pattern (digits only)
	@DELETE
	@Produces(MediaType.APPLICATION_JSON)

	public void removeCustomer( @PathParam("id") long customerId ) throws Exception {
		logger.debug("removeCustomer " + customerId);
		
		AdminFacade adminFacade = getAdminFacade();
		adminFacade.removeCustomer(customerId);
	}
	
	@DELETE
	@Path("/customer")
	@Consumes(MediaType.APPLICATION_JSON)
	@Produces(MediaType.APPLICATION_JSON)

 	public void removeCustomer(Customer customer) throws Exception {
		logger.debug("removeCustomer " + customer);

		AdminFacade adminFacade = getAdminFacade();
		try {
			adminFacade.removeCustomer(customer);
		} catch (Exception e) {
			logger.error("removeCustomer failed : " + e.toString());
			throw e;
		}

	}
	
	
	// system configuration services
	
	@Path("/sleep/{sleep : \\d+}") //  (digits only)
	@POST
	@Produces(MediaType.APPLICATION_JSON)

 	public void setDailyTaskSleepTime( @PathParam("sleep") long sleepTime ) throws Exception {
		logger.debug("setDailyTaskSleepTime " + sleepTime);

		CouponSystem couponSystem = CouponSystem.getInstance();
		couponSystem.setDailyTaskSleepTime(sleepTime * Utils.MINUTE);
	}
 
	
}