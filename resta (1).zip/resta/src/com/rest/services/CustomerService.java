package com.rest.services;

import java.sql.SQLException;
import java.util.Collection;
import java.util.Date;

import javax.servlet.http.HttpServletRequest;
import javax.ws.rs.Consumes;
import javax.ws.rs.GET;
import javax.ws.rs.POST;
import javax.ws.rs.PUT;
import javax.ws.rs.Path;
import javax.ws.rs.PathParam;
import javax.ws.rs.Produces;
import javax.ws.rs.core.Context;
import javax.ws.rs.core.MediaType;

import org.apache.log4j.Logger;

import com.coupon.basic.Coupon;
import com.coupon.basic.CouponType;
import com.coupon.basic.Customer;
import com.coupon.exceptions.CouponProjectException;
import com.coupon.exceptions.CouponProjectException.LoginException;
import com.coupon.facade.CustomerFacade;
import com.coupon.util.Utils;
import com.rest.auth.AuthUtils;
/**
 * 
 * @author Elad
 *
 */


//Sets the path to base URL + /customer
@Path("/customer")
@Produces(MediaType.APPLICATION_JSON)
//done.........................................
public class CustomerService {

	static Logger logger = Logger.getLogger(CustomerService.class);

	@Context
	HttpServletRequest request;

	private CustomerFacade getCustomerFacade() throws LoginException {
		return AuthUtils.getCredentials(CustomerFacade.class, request);
	}

	// example :
	// http://localhost:9090/resta/customer/current
	//
	@Path("/current")
	@GET
	public Customer getCurrentCustomer() throws Exception {
		logger.debug("getCurrentCustomer");
		System.out.println("CustomerService.getCurrentCustomer()");
		CustomerFacade customerFacade = getCustomerFacade();
		return customerFacade.getCustomer();
	}

	@Path("/current") 
	@PUT
	@Consumes(MediaType.APPLICATION_JSON)
	public void updateCurrentCustomer(Customer customer) throws Exception {
		logger.debug("updateCurrentCustomer " + customer);		

		CustomerFacade customerFacade = getCustomerFacade();
		customerFacade.updateCustomer(customer);
	}	

	// example :
	// http://localhost:9090/resta/customer/coupons
	//
	@Path("/coupons")
	@GET
	public Collection<Coupon> getAllPurchasedCoupons() throws Exception {
		logger.debug("getAllPurchasedCoupons");
		System.out.println("CustomerService.getAllPurchasedCoupons()");
		CustomerFacade customerFacade = getCustomerFacade();
		return customerFacade.getAllPurchasedCoupons();
	}

	// example :
	// http://localhost:9090/resta/customer/coupons/SPORTS
	//
	@Path("/coupons/{CouponType}") 
	@GET
	public Collection<Coupon> getAllPurchasedCouponsByType(@PathParam("CouponType") CouponType couponType) throws Exception     {
		logger.debug("getAllPurchasedCouponsByType " + couponType);
		System.out.println("CustomerService.getAllPurchasedCouponsByType()");
		CustomerFacade customerFacade = getCustomerFacade();
		try {
			return customerFacade.getAllPurchasedCouponsByType(couponType);
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (CouponProjectException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return getAllPurchasedCoupons();
	}

	// example :
	// http://localhost:8080/resta/customer/coupons/100
	//
	@Path("/coupons/{price : \\d+}") 
	@GET
	public Collection<Coupon> getAllPurchasedCouponsByPrice(@PathParam("price") int couponPrice) throws CouponProjectException, SQLException     {
		logger.debug("getAllPurchasedCouponsByPrice " + couponPrice);		
		System.out.println("CustomerService.getAllPurchasedCouponsByPrice()");
		CustomerFacade customerFacade = getCustomerFacade();
		try {
			customerFacade = getCustomerFacade();
		} catch (LoginException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return customerFacade.getAllPurchasedCouponsByPrice(couponPrice);
	}

	// example :
	// http://localhost:9090/resta/company/coupons/2016-12-24
	//
	@Path("/coupons/date/{toDate}") 
	@GET
	public Collection<Coupon> getAllPurchasedCouponsByDate(@PathParam("toDate") Date toDate) throws Exception {
		logger.debug("getAllPurchasedCouponsByDate " + toDate);
		System.out.println("CustomerService.getAllPurchasedCouponsByDate()");
		CustomerFacade customerFacade = getCustomerFacade();
		try {
			//			LocalDate date = LocalDate.from(toDate) ;
			return customerFacade.getAllPurchasedCouponsByDate(toDate);
		}
		catch (Exception e) {
			throw new CouponProjectException("Invalid date : " + toDate);
		}
	}	


	// example :
	// http://localhost:9090/resta/customer/coupons
	//
	@Path("/buylist")
	@GET
	public Collection<Coupon> getPurchableCoupons() throws Exception     {
		logger.debug("getPurchableCoupons");
		System.out.println("CustomerService.getPurchableCoupons()");
		CustomerFacade customerFacade = getCustomerFacade();
		try {
			return customerFacade.getPurchableCoupons();
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return getAllPurchasedCoupons();
	}

	// example :
	// http://localhost:9090/resta/customer/buylist/SPORTS
	//
	@Path("/buylist/{CouponType}") 
	@GET
	public Collection<Coupon> getPurchableCouponsByType(@PathParam("CouponType") CouponType couponType) throws Exception   {
		logger.debug("getPurchableCouponsByType " + couponType);

		CustomerFacade customerFacade = getCustomerFacade();
		try {
			customerFacade = getCustomerFacade();
		} catch (LoginException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return customerFacade.getPurchableCouponsByType(couponType);
	}

	// example :
	// http://localhost:9090/resta/customer/buylist/100
	//
	@Path("/buylist/{price : \\d+}") 
	@GET
	public Collection<Coupon> getPurchableCouponsByPrice(@PathParam("price") int couponPrice) throws Exception {
		logger.debug("getPurchableCouponsByPrice " + couponPrice);		

		CustomerFacade customerFacade = getCustomerFacade();
		return customerFacade.getPurchableCouponsByPrice(couponPrice);
	}

	//	 example :
	//	 http://localhost:9090/resta/company/buylist/2016-12-24
	//
	@Path("/buylist/date/{toDate}") 
	@GET
	public Collection<Coupon> getPurchableCouponsByDate(@PathParam("toDate") String toDate) throws Exception {
		logger.debug("getPurchableCouponsByDate " + toDate);

		CustomerFacade customerFacade = getCustomerFacade();
		try {
			Date date = Utils.string2Date(toDate);
			return customerFacade.getPurchableCouponsByDate(date);
		}
		catch (Exception e) {
			e.printStackTrace();

			throw new CouponProjectException("Invalid date : " + toDate);
		}
	}	


	@Path("/buy") 
	@POST
	@Consumes(MediaType.APPLICATION_JSON)
	public void purchaseCoupon(String couponName) throws LoginException {
		logger.debug("purchaseCoupon " + couponName);		

		CustomerFacade customerFacade = getCustomerFacade();
		try {
			customerFacade.purchaseCoupon(couponName);
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}


	@Path("/buy") 
	@POST
	//	@Consumes(MediaType.APPLICATION_JSON)
	public void purchaseCoupon(Coupon Coupon) throws LoginException  {
		logger.debug("purchaseCoupon " + Coupon);		

		CustomerFacade customerFacade = getCustomerFacade();
		try {
			customerFacade.purchaseCoupon(Coupon);
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}

	// example :
	// http://localhost:9090/resta/customer/coupontypes
	//
	@Path("/coupontypes")
	@GET
	public CouponType[] getCouponTypes() throws Exception {
		logger.debug("getCouponTypes");

		return CouponType.values();
	}

}