package com.rest.services;

import java.util.Collection;
import java.util.Date;

import javax.servlet.http.HttpServletRequest;
import javax.ws.rs.Consumes;
import javax.ws.rs.DELETE;
import javax.ws.rs.GET;
import javax.ws.rs.POST;
import javax.ws.rs.PUT;
import javax.ws.rs.Path;
import javax.ws.rs.PathParam;
import javax.ws.rs.Produces;
import javax.ws.rs.core.Context;
import javax.ws.rs.core.MediaType;

import org.apache.log4j.Logger;

import com.coupon.basic.Company;
import com.coupon.basic.Coupon;
import com.coupon.basic.CouponType;
import com.coupon.exceptions.CouponProjectException;
import com.coupon.exceptions.CouponProjectException.LoginException;
import com.coupon.facade.CompanyFacade;
import com.coupon.util.Utils;
import com.rest.auth.AuthUtils;
/**
 * 
 * @author Elad
 *
 */


//Sets the path to base URL + /company
@Path("/company")
@Produces(MediaType.APPLICATION_JSON)
//done...........
public class CompanyService {

	static Logger logger = Logger.getLogger(CompanyService.class);

	@Context
	HttpServletRequest request;

	private CompanyFacade getCompanyFacade() throws LoginException {
		return AuthUtils.getCredentials(CompanyFacade.class, request);
	}	
	
	// Handling companies
	
	// example :
	// http://localhost:9090/resta/company/current
	//
	@Path("/current")
	@GET
 	public Company getCurrentCompany() throws Exception {
		logger.debug("getCurrentCompany");

		CompanyFacade companyFacade = getCompanyFacade();
    	return companyFacade.getCompany();
	}
	
	@Path("/current") 
	@PUT
	@Consumes(MediaType.APPLICATION_JSON)
	public void updateCurrentCompany(Company company) throws Exception {
		logger.debug("updateCurrentCompany " + company);		

		CompanyFacade companyFacade = getCompanyFacade();
    	companyFacade.updateCompany(company);
	}	
	
	
	// example :
	// http://localhost:9090/resta/company/coupon/5
	//
	@Path("/coupon/{id : \\d+}") // id pattern (digits only)
	@GET
 	public Coupon getCoupon( @PathParam("id") long couponId ) throws Exception {
		logger.debug("getCoupon " + couponId);

		CompanyFacade companyFacade = getCompanyFacade();
    	return companyFacade.getCouponByID(couponId);
	}
	
	// example :
	// http://localhost:9090/resta/company/coupon/messi
	//	
	@Path("/coupon/{name: [a-zA-Z][a-zA-Z_0-9%]+}") // name pattern
	@GET
 	public Coupon getCoupon( @PathParam("name") String couponName ) throws Exception {
		logger.debug("getCoupon " + couponName);

		CompanyFacade companyFacade = getCompanyFacade();
    	return companyFacade.getCouponByTitle(couponName);
	}
	
	// example :
	// http://localhost:9090/resta/company/coupons
	//	 
	@Path("/coupons") 
	@GET
 	public Collection<Coupon> getCoupons() throws Exception{
		logger.debug("getCoupons" );

		CompanyFacade companyFacade = getCompanyFacade();
    	return companyFacade.getAllCoupons();
	}
	
	// example :
	// http://localhost:9090/resta/company/coupons/SPORTS
	//
	@Path("/coupons/{CouponType}") 
	@GET
 	public Collection<Coupon> getCouponsByType(@PathParam("CouponType") CouponType couponType) throws Exception {
		logger.debug("getCouponsByType " + couponType);
		

		CompanyFacade companyFacade = getCompanyFacade();
    	return companyFacade.getCouponsByType(couponType);
	}
	
	// example :
	// http://localhost:9090/resta/company/coupons/150
	//
	@Path("/coupons/{price : \\d+}") 
	@GET
 	public Collection<Coupon> getCouponsByPrice(@PathParam("price") int couponPrice) throws Exception {
		logger.debug("getCouponsByPrice " + couponPrice);		

		CompanyFacade companyFacade = getCompanyFacade();
    	return companyFacade.getCouponsByPrice(couponPrice);
	}

	// example :
	// http://localhost:9090/resta/company/coupons/2016-12-24
	//
	@Path("/coupons/date/{toDate}") 
	@GET
 	public Collection<Coupon> getCouponsByDate(@PathParam("toDate") String toDate) throws Exception {
		logger.debug("getCouponsByDate " + toDate);
		
		CompanyFacade companyFacade = getCompanyFacade();
		try {
			Date date = Utils.string2Date(toDate);
	    	return companyFacade.getCouponsByDate(date);
		}
		catch (Exception e) {
			throw new CouponProjectException("Invalid date : " + toDate);
		}
	}	

	// example :
	// http://localhost:9090/resta/company/coupon

	@POST
	@Path("/coupon")
	@Consumes(MediaType.APPLICATION_JSON)
	//@Produces(MediaType.APPLICATION_JSON)
	public void createCoupon(Coupon coupon) throws Exception {
		logger.debug("createCoupon " + coupon);

		CompanyFacade companyFacade = getCompanyFacade();
		
		try {
			companyFacade.createCoupon(coupon);
		} catch (Exception e) {
			logger.error("createCoupon failed : " + e.toString());
			throw e;
		}

	}	
	
	
	// example :
	// http://localhost:9090/resta/company/coupon
 
	@PUT
	@Path("/coupon")
	@Consumes(MediaType.APPLICATION_JSON)
	//@Produces(MediaType.APPLICATION_JSON)
	public void updateCoupon(Coupon coupon) throws Exception {
		logger.debug("updateCoupon " + coupon);

		CompanyFacade companyFacade = getCompanyFacade();
		
		try {
			companyFacade.updateCoupon(coupon);
		} catch (Exception e) {
			logger.error("updateCoupon failed : " + e.toString());
			throw e;
		}

	}
	
	// example :
	// http://localhost:9090/resta/company/coupon/1
	//	
	@Path("/coupon/{id : \\d+}") // id pattern (digits only)
	@DELETE
	public void removeCoupon( @PathParam("id") long couponId ) throws Exception {
		logger.debug("removeCoupon " + couponId);
		
		CompanyFacade companyFacade = getCompanyFacade();
		companyFacade.removeCoupon(couponId);
	}
	
	@DELETE
	@Path("/coupon")
	@Consumes(MediaType.APPLICATION_JSON)
 	public void removeCoupon(Coupon coupon) throws Exception {
		logger.debug("removeCoupon " + coupon);

		CompanyFacade companyFacade = getCompanyFacade();
		try {
			companyFacade.removeCoupon(coupon);
		} catch (Exception e) {
			logger.error("removeCoupon failed : " + e.toString());
			throw e;
		}

	}
	
	// example :
	// http://localhost:9090/resta/company/coupontypes
	//
	@Path("/coupontypes")
	@GET
 	public CouponType[] getCouponTypes() throws Exception {
		logger.debug("getCouponTypes");
		
		return CouponType.values();
	}	

} 