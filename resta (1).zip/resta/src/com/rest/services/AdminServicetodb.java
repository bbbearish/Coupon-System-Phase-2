package com.rest.services;

 
import javax.ws.rs.GET;
import javax.ws.rs.Path;

import com.coupon.basic.Company;
import com.coupon.exceptions.CouponProjectException.CompanyException;
import com.coupon.exceptions.CouponProjectException.activationException;
import com.coupon.facade.AdminFacade; 
//done......
/**
 * 
 * @author Elad
 *
 */
@Path("/admin")
public class AdminServicetodb {
	//http://localhost:9090/resta/rest/admin/hello
	@Path("/hello")
	@GET
	public Company getCompany(long ID) throws CompanyException, activationException{
		AdminFacade adminFacade = new AdminFacade() ;
		return adminFacade.getCompanyByID(120);
	}
	
	
	
	
	
	
	
	
}